package configreader;

public class ObjectRepository  {

	public static ConfigReader reader;
}
