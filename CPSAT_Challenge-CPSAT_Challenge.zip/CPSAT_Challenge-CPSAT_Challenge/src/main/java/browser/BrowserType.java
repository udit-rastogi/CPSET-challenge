package browser;

public enum BrowserType {
	Firefox,
	Iexplorer,
	Chrome
}
